library(keras)

class_names <- c('T-shirt/top','Trouser','Pullover','Dress','Coat',
                 'Sandal','Shirt','Sneaker','Bag','Ankle boot')

build_model <- function(input_shape = c(28,28,1), num_classes = 10) {
  model <- keras_model_sequential(name='fashion_cnn_6layer') %>%
    layer_conv_2d(filters = 32, kernel_size = 3, activation = 'relu', padding='same', input_shape = input_shape) %>%
    layer_conv_2d(filters = 64, kernel_size = 3, activation = 'relu', padding='same') %>%
    layer_max_pooling_2d(pool_size = 2) %>%
    layer_conv_2d(filters = 128, kernel_size = 3, activation = 'relu', padding='same') %>%
    layer_flatten() %>%
    layer_dense(units = num_classes, activation = 'softmax')

  model %>% compile(
    optimizer = 'adam',
    loss = 'sparse_categorical_crossentropy',
    metrics = 'accuracy'
  )
  model
}

mnist <- dataset_fashion_mnist()

x_train <- mnist$train$x / 255
x_test <- mnist$test$x / 255
x_train <- array_reshape(x_train, c(dim(x_train)[1], 28, 28, 1))
x_test <- array_reshape(x_test, c(dim(x_test)[1], 28, 28, 1))
y_train <- mnist$train$y
y_test <- mnist$test$y

model <- build_model(input_shape = c(28,28,1))
summary(model)
model %>% fit(x_train, y_train, epochs = 5, batch_size = 128, validation_split = 0.1)

save_model_hdf5(model, 'fashion_cnn_r.h5')

indices <- c(0,1)
for (i in indices) {
  probs <- predict(model, array_reshape(x_test[i+1,,,], c(1,28,28,1)))
  pred <- which.max(probs) - 1L
  cat(sprintf("Test idx: %d\nTrue: %d (%s)\nPred: %d (%s) — prob: %.4f\n----\n",
              i, y_test[i+1], class_names[y_test[i+1]+1],
              pred, class_names[pred+1], probs[1,pred+1]))
}
