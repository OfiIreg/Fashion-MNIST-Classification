import argparse
import numpy as np
from tensorflow import keras
from tensorflow.keras import layers

CLASS_NAMES = [
    'T-shirt/top','Trouser','Pullover','Dress','Coat',
    'Sandal','Shirt','Sneaker','Bag','Ankle boot'
]

def build_model(input_shape=(28,28,1), num_classes=10):
    model = keras.Sequential([
        layers.Input(shape=input_shape),
        layers.Conv2D(32, kernel_size=3, activation='relu', padding='same'),
        layers.Conv2D(64, kernel_size=3, activation='relu', padding='same'),
        layers.MaxPooling2D(pool_size=2),
        layers.Conv2D(128, kernel_size=3, activation='relu', padding='same'),
        layers.Flatten(),
        layers.Dense(num_classes, activation='softmax')
    ], name='fashion_cnn_6layer')

    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    return model

def load_data_from_keras():
    (x_train, y_train), (x_test, y_test) = keras.datasets.fashion_mnist.load_data()
    x_train = x_train.astype('float32') / 255.0
    x_test = x_test.astype('float32') / 255.0
    x_train = np.expand_dims(x_train, -1)
    x_test = np.expand_dims(x_test, -1)
    return (x_train, y_train), (x_test, y_test)

def run_training(epochs=5, batch_size=128, save_path='fashion_cnn.h5'):
    (x_train, y_train), (x_test, y_test) = load_data_from_keras()
    model = build_model(input_shape=x_train.shape[1:])
    model.summary()
    model.fit(x_train, y_train, validation_split=0.1, epochs=epochs, batch_size=batch_size)
    model.save(save_path)
    return model, (x_test, y_test)

def predict_examples(model, x_test, y_test, indices=(0, 1)):
    for idx in indices:
        img = np.expand_dims(x_test[idx], axis=0)
        probs = model.predict(img, verbose=0)[0]
        pred = int(np.argmax(probs))
        print(f"Test index: {idx}")
        print(f"True label: {y_test[idx]} ({CLASS_NAMES[y_test[idx]]})")
        print(f"Predicted: {pred} ({CLASS_NAMES[pred]}) — prob: {probs[pred]:.4f}")
        print('-'*40)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument('--model_out', type=str, default='fashion_cnn.h5')
    args = parser.parse_args()

    model, (x_test, y_test) = run_training(epochs=args.epochs, batch_size=args.batch_size, save_path=args.model_out)
    predict_examples(model, x_test, y_test, indices=(0, 1))
